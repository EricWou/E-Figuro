﻿using E_Figuro_API.Models;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Windows;

namespace E_Figuro_WPF
{
    /// <summary>
    /// Interaction logic for Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        HttpClient httpclient = new HttpClient();
        private string userID;

        public Registration()
        {
            InitializeComponent();
        }

        public Registration(string userID)
        {
            InitializeComponent();

            httpclient.BaseAddress = new Uri("https://localhost:7238/EFiguro/");

            httpclient.DefaultRequestHeaders.Accept.Clear();

            httpclient.DefaultRequestHeaders.Accept.Add
                (new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            this.userID = userID;
        }

        private async void create_button_Click(object sender, RoutedEventArgs e)
        {
            HttpResponseMessage response = new HttpResponseMessage();

            //checking for if there are empty textboxes
            if (!string.IsNullOrEmpty(id_box.Text) && !string.IsNullOrEmpty(name_box.Text) 
                && !string.IsNullOrEmpty(email_box.Text) && !string.IsNullOrEmpty(password_box.Text) 
                && !string.IsNullOrEmpty(position_box.Text) && !string.IsNullOrEmpty(department_box.Text) 
                && !string.IsNullOrEmpty(hire_date_box.Text) && !string.IsNullOrEmpty(salary_box.Text) 
                && !string.IsNullOrEmpty(birth_date_box.Text) && !string.IsNullOrEmpty(address_box.Text))
            {
                if (admin_radio.IsChecked == true)
                {
                    Administrator user = new Administrator();

                    user.admin_id = id_box.Text;
                    user.admin_name = name_box.Text;
                    user.admin_email = email_box.Text;
                    user.admin_password = password_box.Text;
                    user.admin_position = position_box.Text;
                    user.admin_department = department_box.Text;
                    user.admin_hire_date = DateTime.Parse(hire_date_box.Text);
                    user.admin_salary = Math.Round(float.Parse(salary_box.Text), 2);
                    user.admin_birth_date = DateTime.Parse(birth_date_box.Text);
                    user.admin_address = address_box.Text;

                    response = await httpclient.PostAsJsonAsync("CreateAdminUser", user);

                    var content = await response.Content.ReadAsStringAsync();

                    //for some reason (response.IsSuccessStatusCode) was not working as a condition,
                    //it was always returning true even with an unsuccessfuly insertion request
                    //however this way produces the correct message output using response.status_message
                    if (content.Contains("Success, administrator user created"))
                    {
                        MessageBox.Show("Success, administrator user created");
                    }
                    else if (content.Contains("Error, duplicate record detected")) 
                    {
                        MessageBox.Show("Error, duplicate record detected");
                    }
                    else
                    {
                        MessageBox.Show("Error when handling request");
                    }
                }
                else if (employee_radio.IsChecked == true)
                {
                    Employee user = new Employee();

                    user.emp_id = id_box.Text;
                    user.emp_name = name_box.Text;
                    user.emp_email = email_box.Text;
                    user.emp_password = password_box.Text;
                    user.emp_position = position_box.Text;
                    user.emp_department = department_box.Text;
                    user.emp_hire_date = DateTime.Parse(hire_date_box.Text);
                    user.emp_salary = Math.Round(float.Parse(salary_box.Text), 2);
                    user.emp_birth_date = DateTime.Parse(birth_date_box.Text);
                    user.emp_address = address_box.Text;

                    response = await httpclient.PostAsJsonAsync("CreateEmpUser", user);

                    var content = await response.Content.ReadAsStringAsync();

                    if (content.Contains("Success, employee user created"))
                    {
                        MessageBox.Show("Success, employee user created");
                    }
                    else if (content.Contains("Error, duplicate record detected"))
                    {
                        MessageBox.Show("Error, duplicate record detected");
                    }
                    else
                    {
                        MessageBox.Show("Error when handling request");
                    }
                }
            }
            else
            {
                MessageBox.Show("Please ensure all textboxes are filled for creating a profile");
            }
        }

        private async void select_button_Click(object sender, RoutedEventArgs e)
        {
            string id = id_box.Text;
            Response response = null;

            if (!string.IsNullOrEmpty(id_box.Text))
            {
                if (admin_radio.IsChecked == true)
                {
                    var serverResponse = await httpclient.GetStringAsync("GetAdminUserByID/" + id);
                    response = JsonConvert.DeserializeObject<Response>(serverResponse);

                    Administrator user = new Administrator();
                    user = response.admin_user;

                    if (response.status_code == 200)
                    {
                        name_box.Text = user.admin_name;
                        email_box.Text = user.admin_email;
                        password_box.Text = user.admin_password;
                        position_box.Text = user.admin_position;
                        department_box.Text = user.admin_department;
                        hire_date_box.Text = user.admin_hire_date.ToShortDateString();
                        salary_box.Text = user.admin_salary.ToString();
                        birth_date_box.Text = user.admin_birth_date.ToShortDateString();
                        address_box.Text = user.admin_address;
                    }
                    else
                    {
                        MessageBox.Show("Please recheck the ID");
                    }
                }
                else if (employee_radio.IsChecked == true)
                {
                    var serverResponse = await httpclient.GetStringAsync("GetEmpUserByID/" + id);
                    response = JsonConvert.DeserializeObject<Response>(serverResponse);

                    Employee user = new Employee();
                    user = response.emp_user;

                    if (response.status_code == 200)
                    {
                        name_box.Text = user.emp_name;
                        email_box.Text = user.emp_email;
                        password_box.Text = user.emp_password;
                        position_box.Text = user.emp_position;
                        department_box.Text = user.emp_department;
                        hire_date_box.Text = user.emp_hire_date.ToShortDateString();
                        salary_box.Text = user.emp_salary.ToString();
                        birth_date_box.Text = user.emp_birth_date.ToShortDateString();
                        address_box.Text = user.emp_address;
                    }
                    else
                    {
                        MessageBox.Show("Please recheck the ID");
                    }
                }
            }
            else
            {
                MessageBox.Show("Please input an ID");
            }
        }

        private async void update_button_Click(object sender, RoutedEventArgs e)
        {
            HttpResponseMessage response = new HttpResponseMessage();
            string id = id_box.Text;

            if (!string.IsNullOrEmpty(id_box.Text) && !string.IsNullOrEmpty(name_box.Text)
                && !string.IsNullOrEmpty(email_box.Text) && !string.IsNullOrEmpty(password_box.Text)
                && !string.IsNullOrEmpty(position_box.Text) && !string.IsNullOrEmpty(department_box.Text)
                && !string.IsNullOrEmpty(hire_date_box.Text) && !string.IsNullOrEmpty(salary_box.Text)
                && !string.IsNullOrEmpty(birth_date_box.Text) && !string.IsNullOrEmpty(address_box.Text))
            {
                if (admin_radio.IsChecked == true)
                {
                    Administrator user = new Administrator();

                    user.admin_id = id_box.Text;
                    user.admin_name = name_box.Text;
                    user.admin_email = email_box.Text;
                    user.admin_password = password_box.Text;
                    user.admin_position = position_box.Text;
                    user.admin_department = department_box.Text;
                    user.admin_hire_date = DateTime.Parse(hire_date_box.Text);
                    user.admin_salary = Math.Round(float.Parse(salary_box.Text), 2);
                    user.admin_birth_date = DateTime.Parse(birth_date_box.Text);
                    user.admin_address = address_box.Text;

                    response = await httpclient.PutAsJsonAsync("UpdateAdminUser/" + id, user);

                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Administrator profile updated succesfully");
                    }
                    else
                    {
                        MessageBox.Show("Error when handling request");
                    }
                }
                else if (employee_radio.IsChecked == true)
                {
                    Employee user = new Employee();

                    user.emp_id = id_box.Text;
                    user.emp_name = name_box.Text;
                    user.emp_email = email_box.Text;
                    user.emp_password = password_box.Text;
                    user.emp_position = position_box.Text;
                    user.emp_department = department_box.Text;
                    user.emp_hire_date = DateTime.Parse(hire_date_box.Text);
                    user.emp_salary = Math.Round(float.Parse(salary_box.Text), 2);
                    user.emp_birth_date = DateTime.Parse(birth_date_box.Text);
                    user.emp_address = address_box.Text;

                    response = await httpclient.PutAsJsonAsync("UpdateEmpUser/" + id, user);

                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Employee profile updated succesfully");
                    }
                    else
                    {
                        MessageBox.Show("Error when handling request");
                    }
                }
            }
            else
            {
                MessageBox.Show("Please ensure all textboxes are filled for updating a profile");
            }
        }

        private async void delete_button_Click(object sender, object e)
        {
            HttpResponseMessage response = new HttpResponseMessage();
            string id = id_box.Text;

            if (admin_radio.IsChecked == true)
            {
                response = await httpclient.DeleteAsync("DeleteAdminUser/" + id);

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Administrator profile deleted succesfully");
                }
                else
                {
                    MessageBox.Show("Error when handling request");
                }
            }
            else if (employee_radio.IsChecked == true)
            {
                response = await httpclient.DeleteAsync("DeleteEmpUser/" + id);

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Employee profile deleted succesfully");
                }
                else
                {
                    MessageBox.Show("Error when handling request");
                }
            }
        }

        private void back_button_Click(object sender, RoutedEventArgs e)
        {
            Features window1 = new Features(userID);
            window1.Show();
            this.Close();
        }
    }
}
