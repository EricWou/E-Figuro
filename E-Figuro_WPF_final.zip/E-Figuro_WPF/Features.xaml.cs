﻿using System;
using System.Windows;

namespace E_Figuro_WPF
{
    /// <summary>
    /// Interaction logic for Features.xaml
    /// </summary>
    public partial class Features : Window
    {
        private String userID;

        public Features()
        {
            InitializeComponent();
        }

        public Features(string userID)
        {
            InitializeComponent();

            this.userID = userID;
        }

        private void profile_button_Click(object sender, RoutedEventArgs e)
        {
            Profile window1 = new Profile(userID);
            window1.Show();
            this.Close();
        }

        private void registration_button_Click(object sender, RoutedEventArgs e)
        {
            if (userID.Substring(0, 1) == "A")
            {
                Registration window2 = new Registration(userID);
                window2.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("You do not have access to this portal as an employee");
            }
        }

        private void payroll_button_Click(object sender, RoutedEventArgs e)
        {
            Payroll window3 = new Payroll(userID);
            window3.Show();
            this.Close();
        }

        private void clock_button_Click(object sender, RoutedEventArgs e)
        {
            Clock window4 = new Clock(userID);
            window4.Show();
            this.Close();
        }

        private void timesheet_button_Click(object sender, RoutedEventArgs e)
        {
            TimeSheet_page window5 = new TimeSheet_page(userID);
            window5.Show();
            this.Close();
        }

        private void leave_button_Click(object sender, RoutedEventArgs e)
        {
            Leave_page window6 = new Leave_page(userID);
            window6.Show();
            this.Close();
        }

        private void logout_button_Click(object sender, RoutedEventArgs e)
        {
            userID = "";
            MainWindow window7 = new MainWindow();
            window7.Show();
            this.Close();
        }
    }
}
