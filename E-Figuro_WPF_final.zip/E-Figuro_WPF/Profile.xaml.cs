﻿using E_Figuro_API.Models;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Windows;

namespace E_Figuro_WPF
{
    /// <summary>
    /// Interaction logic for Profile.xaml
    /// </summary>
    public partial class Profile : Window
    {
        HttpClient httpclient = new HttpClient();
        private string userID;

        public Profile()
        {
            InitializeComponent();
        }
        public Profile(string userID)
        {
            InitializeComponent();

            httpclient.BaseAddress = new Uri("https://localhost:7238/EFiguro/");

            httpclient.DefaultRequestHeaders.Accept.Clear();

            httpclient.DefaultRequestHeaders.Accept.Add
                (new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            this.userID = userID;

            retrieveUserProfile();
        }

        private async void retrieveUserProfile()
        {
            if (userID.Substring(0, 1) == "A")
            {
                var serverResponse = await httpclient.GetStringAsync("GetAdminUserByID/" + userID);
                Response response = JsonConvert.DeserializeObject<Response>(serverResponse);

                Administrator user = new Administrator();
                user = response.admin_user;

                if (response.status_code == 200)
                {
                    name_label.Content = user.admin_name;
                    position_label.Content = user.admin_position;
                    id_label.Content = user.admin_id;
                    department_label.Content = user.admin_department;
                    hire_date_label.Content = user.admin_hire_date.ToShortDateString();
                    email_label.Content = user.admin_email;
                    birth_date_label.Content = user.admin_birth_date.ToShortDateString();
                    address_label.Content = user.admin_address;
                }
                else
                {
                    MessageBox.Show("Error with retrieving information");
                }
            }
            else if (userID.Substring(0,1) == "E")
            {
                var serverResponse = await httpclient.GetStringAsync("GetEmpUserByID/" + userID);
                Response response = JsonConvert.DeserializeObject<Response>(serverResponse);

                Employee user = new Employee();
                user = response.emp_user;

                if (response.status_code == 200)
                {
                    name_label.Content = user.emp_name;
                    position_label.Content = user.emp_position;
                    id_label.Content = user.emp_id;
                    department_label.Content = user.emp_department;
                    hire_date_label.Content = user.emp_hire_date.ToShortDateString();
                    email_label.Content = user.emp_email;
                    birth_date_label.Content = user.emp_birth_date.ToShortDateString();
                    address_label.Content = user.emp_address;
                }
                else
                {
                    MessageBox.Show("Error with retrieving information");
                }
            }
        }

        private void back_button_Click(object sender, RoutedEventArgs e)
        {
            Features window1 = new Features(userID);
            window1.Show();
            this.Close();
        }
    }
}
