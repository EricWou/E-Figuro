﻿using E_Figuro_API.Models;
using E_Figuro_WPF.Models;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace E_Figuro_WPF
{
    /// <summary>
    /// Interaction logic for Payroll.xaml
    /// </summary>
    public partial class Payroll : Window
    {
        HttpClient httpclient = new HttpClient();
        private string userID;

        // - begin exported instance variables to PayrollClass.cs
        /*
        const double taxes = 0.25;
        private double salary;
        private double totalHours;
        */
        // - end exported instance variables to PayrollClass.cs

        PayrollClass currentUser;

        public Payroll()
        {
            InitializeComponent();
        }

        public Payroll(string userID)
        {
            InitializeComponent();

            httpclient.BaseAddress = new Uri("https://localhost:7238/EFiguro/");

            httpclient.DefaultRequestHeaders.Accept.Clear();

            httpclient.DefaultRequestHeaders.Accept.Add
                (new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            currentUser = new PayrollClass();       //new code for PayrollClass
            this.userID = userID;

            InitializePage();
        }

        private async Task InitializePage()
        {
            //need to have this method because the retrieveUserInfo() and retrieveTotalHours() both have await
            //and the calculateEarnings(), calculateTaxes(), calculateNetPay() methods depend on the await
            //methods to retrieve data from the database in order to perform calculations. Because await
            //methods are asynchronous, it is possible that the non-await methods happen first and will not
            //have the proper values yet. So this method alleviates this issue.
            await retrieveUserInfo();
            await retrieveTotalHours();
            earnings_label.Content = currentUser.calculateEarnings().ToString();
            taxes_label.Content = currentUser.calculateTaxes().ToString();
            netPay_label.Content = currentUser.calculateNetPay().ToString();
        }

        private async Task retrieveUserInfo()
        {
            if (userID.Substring(0, 1) == "A")
            {
                var serverResponse = await httpclient.GetStringAsync("GetAdminUserByID/" + userID);
                Response response = JsonConvert.DeserializeObject<Response>(serverResponse);

                Administrator user = new Administrator();
                user = response.admin_user;

                if (response.status_code == 200)    //ie if response is successful
                {
                    name_label.Content = user.admin_name;
                    //this.salary = user.admin_salary;
                    currentUser.setSalary(user.admin_salary);       //new code for PayrollClass
                    salary_label.Content = user.admin_salary.ToString();
                }
                else
                {
                    MessageBox.Show("Error with retrieving information");
                }
            }
            else if (userID.Substring(0, 1) == "E")
            {
                var serverResponse = await httpclient.GetStringAsync("GetEmpUserByID/" + userID);
                Response response = JsonConvert.DeserializeObject<Response>(serverResponse);

                Employee user = new Employee();
                user = response.emp_user;

                if (response.status_code == 200)
                {
                    name_label.Content = user.emp_name;
                    //this.salary = user.emp_salary;
                    currentUser.setSalary(user.emp_salary);         //new code for PayrollClass
                    salary_label.Content = user.emp_salary.ToString();
                }
                else
                {
                    MessageBox.Show("Error with retrieving information");
                }
            }
        }

        private async Task retrieveTotalHours()
        {
            var serverResponse = await httpclient.GetStringAsync("GetTotalHoursByUserID/" + userID);
            Response response = JsonConvert.DeserializeObject<Response>(serverResponse);

            if (response.status_code == 200)
            {
                //this.totalHours = response.totalHours;
                currentUser.setTotalHours(response.totalHours);     //new code for PayrollClass
                hours_label.Content = response.totalHours.ToString();
            }
            else
            {
                MessageBox.Show("Error with retrieving information");
            }
            
        }

        // - begin exported methods to PayrollClass.cs
        /*
        public double calculateEarnings()
        {
            double earnings = salary * totalHours;

            return earnings; 
        }

        public double calculateTaxes()
        {
            double taxedSalary = calculateEarnings() * taxes;

            return taxedSalary;
        }

        public double calculateNetPay()
        {
            double netPay = calculateEarnings() - calculateTaxes();

            return netPay;
        }
        */
        // - end exported methods to PayrollClass.cs

        private void print_button_Click(object sender, object e)
        {
            PrintDialog dialog = new PrintDialog();
            if (dialog.ShowDialog() == true)
            {
                dialog.PrintVisual(this, "My Canvas");
            }
        }

        private void back_button_Click(object sender, RoutedEventArgs e)
        {
            Features window1 = new Features(userID);
            window1.Show();
            this.Close();
        }
    }
}
