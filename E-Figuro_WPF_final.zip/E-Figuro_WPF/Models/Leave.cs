﻿using System;

namespace E_Figuro_API.Models
{
    public class Leave
    {
        public string leave_id { get; set; }
        public string emp_id { get; set; }
        public string admin_id { get; set; }
        public int reason_id { get; set; }
        public DateTime start_date { get; set; }
        public DateTime end_date { get; set; }
        public int no_days { get; set; }

    }
}
