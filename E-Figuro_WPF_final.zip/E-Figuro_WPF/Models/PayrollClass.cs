﻿
namespace E_Figuro_WPF.Models
{
    public class PayrollClass
    {
        // class not present in Models folder for E-Figuro_API because not used on the API side

        const double taxes = 0.25;
        private double salary;
        private double totalHours;

        public PayrollClass()
        {
            salary = 0.0;
            totalHours = 0.0;
        }

        public PayrollClass(double salary, double totalHours)
        {
            this.salary = salary;
            this.totalHours = totalHours;
        }   

        public void setSalary(double salary)
        {
            this.salary = salary;
        }

        public void setTotalHours(double totalHours)
        {
            this.totalHours = totalHours;
        }

        public double getSalary()
        {
            return salary;
        }

        public double getTotalHours()
        {
            return totalHours;
        }

        public double calculateEarnings()
        {
            double earnings = salary * totalHours;

            return earnings;
        }

        public double calculateTaxes()
        {
            double taxedSalary = calculateEarnings() * taxes;

            return taxedSalary;
        }

        public double calculateNetPay()
        {
            double netPay = calculateEarnings() - calculateTaxes();

            return netPay;
        }
    }
}
