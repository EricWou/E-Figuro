﻿using System;

namespace E_Figuro_API.Models
{
    public class Administrator
    {
        public string admin_id { get; set; }
        public string admin_name { get; set; }
        public string admin_email { get; set;}
        public string admin_password { get; set; }
        public string admin_position { get; set; }
        public string admin_department { get; set; }
        public DateTime admin_hire_date { get; set; }
        public double admin_salary { get; set; }
        public DateTime admin_birth_date { get; set; }
        public string admin_address { get; set; }
    }
}
