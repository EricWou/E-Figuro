﻿using System;

namespace E_Figuro_API.Models
{
    public class Employee
    {
        public string emp_id { get; set; }
        public string emp_name { get; set; }
        public string emp_email { get; set; }
        public string emp_password { get; set; }
        public string emp_position { get; set; }
        public string emp_department { get; set; }
        public DateTime emp_hire_date { get; set; }
        public double emp_salary { get; set; }
        public DateTime emp_birth_date { get; set; }
        public string emp_address { get; set; }
    }
}
