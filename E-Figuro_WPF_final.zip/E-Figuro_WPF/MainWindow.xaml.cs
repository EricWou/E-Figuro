﻿using E_Figuro_API.Models;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Net.Http;
using System.Windows;

namespace E_Figuro_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        HttpClient httpclient = new HttpClient();

        public MainWindow()
        {
            InitializeComponent();

            httpclient.BaseAddress = new Uri("https://localhost:7238/EFiguro/");

            httpclient.DefaultRequestHeaders.Accept.Clear();

            httpclient.DefaultRequestHeaders.Accept.Add
                (new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        }

        private async void login_button_Click(object sender, RoutedEventArgs e)
        {
            ArrayList login = new ArrayList();      //sending login information as part of an ArrayList
            login.Add(email_box.Text);              //because sending as part of an Object would require
            login.Add(password_box.Password);       //an extra step to deserialize the information
            Response response = null;

            if (admin_radio.IsChecked == true)
            {
                var serverResponse = await httpclient.PostAsJsonAsync("AdminLogin", login);     //POST request is more secure than
                string jsonResponse = await serverResponse.Content.ReadAsStringAsync();         //GET request for login info

                response = JsonConvert.DeserializeObject<Response>(jsonResponse);
            }
            else if (employee_radio.IsChecked == true)
            {
                var serverResponse = await httpclient.PostAsJsonAsync("EmpLogin", login);
                string jsonResponse = await serverResponse.Content.ReadAsStringAsync();

                response = JsonConvert.DeserializeObject<Response>(jsonResponse);
            }

            if (response != null)
            {
                if (response.status_code == 200)
                {
                    string userID = response.login[2].ToString();

                    Features window1 = new Features(userID);
                    window1.Show();
                    this.Close();
                }
                else 
                {
                    MessageBox.Show("Invalid email and/or password");
                }
            }
            else
            {
                MessageBox.Show("Please check your connection to the database");
            }
        }
    }
}
