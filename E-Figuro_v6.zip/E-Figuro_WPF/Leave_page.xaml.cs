﻿using E_Figuro_API.Models;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace E_Figuro_WPF
{
    /// <summary>
    /// Interaction logic for Leave_page.xaml
    /// </summary>
    public partial class Leave_page : Window
    {
        HttpClient httpclient = new HttpClient();
        private string userID;

        public Leave_page()
        {
            InitializeComponent();
        }

        public Leave_page(string userID)
        {
            InitializeComponent();

            httpclient.BaseAddress = new Uri("https://localhost:7238/EFiguro/");

            httpclient.DefaultRequestHeaders.Accept.Clear();

            httpclient.DefaultRequestHeaders.Accept.Add
                (new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            this.userID = userID;
        }

        private void calculate_button_Click(object sender, RoutedEventArgs e)
        {
            DateTime? startDateValue = start_date.SelectedDate;         //the ? allows for nullable values
            DateTime? endDateValue = end_date.SelectedDate;

            if (startDateValue.HasValue && endDateValue.HasValue)
            {
                DateTime startDate = start_date.SelectedDate.Value.Date;
                DateTime endDate = end_date.SelectedDate.Value.Date;

                if (startDateValue <= endDateValue)
                {
                    TimeSpan difference = endDate - startDate;

                    int days = int.Parse(difference.TotalDays.ToString()) + 1;

                    noDays_label.Content = days;
                }
                else
                {
                    MessageBox.Show("Please select a start date that is earlier than the end date");
                }
            }
            else
            {
                MessageBox.Show("Please select a start and end date");
            }
        }

        private async void ViewDaysLeft_button_Click(object sender, RoutedEventArgs e)
        {
            string leaveChoice = "";

            if (holiday_radio.IsChecked == true)
            {
                leaveChoice = "holiday";
            }
            else if (sick_radio.IsChecked == true)
            {
                leaveChoice = "sick";
            }

            string requestURL = $"?userID={userID}&leaveChoice={leaveChoice}";

            var serverResponse = await httpclient.GetStringAsync("GetAllLeaveByID" + requestURL);

            Response response = JsonConvert.DeserializeObject<Response>(serverResponse);

            daysRemaining_label.Content = response.days_remaining;
        }

        private async void SubmitLeaveButton_Click(object sender, RoutedEventArgs e)
        {
            HttpResponseMessage response = new HttpResponseMessage();
            Leave request = new Leave();

            var date = end_date.SelectedDate.Value.ToString("yyyy-MM-dd");
            string leaveID = userID + date;

            DateTime? startDateValue = start_date.SelectedDate;         
            DateTime? endDateValue = end_date.SelectedDate;

            if ((startDateValue.HasValue && endDateValue.HasValue) && (startDateValue <= endDateValue))
            {
                DateTime startDate = start_date.SelectedDate.Value.Date;
                DateTime endDate = end_date.SelectedDate.Value.Date;

                TimeSpan difference = endDate - startDate;

                int days = int.Parse(difference.TotalDays.ToString()) + 1;

                request.leave_id = leaveID;
                if (userID.Substring(0,1) == "A")
                {
                    request.emp_id = "null";
                    request.admin_id = userID;
                }
                else if (userID.Substring(0,1) == "E")
                {
                    request.emp_id = userID;
                    request.admin_id = "null";
                }
                if (holiday_radio.IsChecked == true)
                {
                    request.reason_id = 1;
                }
                else if (sick_radio.IsChecked == true)
                {
                    request.reason_id = 2;
                }
                request.start_date = startDate;
                request.end_date = endDate;
                request.no_days = days;

                response = await httpclient.PostAsJsonAsync("CreateLeaveRequest", request);

                var content = await response.Content.ReadAsStringAsync();

                if (content.Contains("Success, leave request submitted"))
                {
                    MessageBox.Show("Success, leave request submitted");
                }
                else if (content.Contains("Error, duplicate record detected"))
                {
                    MessageBox.Show("Error, duplicate record detected. Select a different end date");
                }
                else
                {
                    MessageBox.Show("Error when handling request");
                }
                
            }
            else
            {
                MessageBox.Show("Please ensure to pick a start date that precedes the end date, and select a reason");
            }
        }

        private void goback_Click(object sender, RoutedEventArgs e)
        {
            Features window1 = new Features(userID);
            window1.Show();
            this.Close();
        }

    }
}
