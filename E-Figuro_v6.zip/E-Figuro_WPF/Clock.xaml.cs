﻿using E_Figuro_API.Models;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace E_Figuro_WPF
{
    /// <summary>
    /// Interaction logic for Clock.xaml
    /// </summary>
    public partial class Clock : Window
    {
        HttpClient httpclient = new HttpClient();
        private string userID;

        public Clock()
        {
            InitializeComponent();
        }

        public Clock(string userID)
        {
            InitializeComponent();

            httpclient.BaseAddress = new Uri("https://localhost:7238/EFiguro/");

            httpclient.DefaultRequestHeaders.Accept.Clear();

            httpclient.DefaultRequestHeaders.Accept.Add
                (new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            this.userID = userID;

            clockDate_label.Content = DateTime.Now.ToString("yyyy-MM-dd");
            clockTime_label.Content = DateTime.Now.ToString("HH:mm:ss");
        }

        private async void clockSubmit_button_Click(object sender, RoutedEventArgs e)
        {
            string timeID = userID + clockDate_label.Content.ToString();
            //in order to get the IsSuccessStatusCode from response to use in if-else statement later
            HttpResponseMessage response = new HttpResponseMessage();

            if (punchIn_radio.IsChecked == true)
            {
                TimeSheet entry = new TimeSheet();
                entry.time_id = timeID;

                if (userID.Substring(0, 1) == "A")
                {
                    entry.emp_id = "null";  //"null" because in the restAPI side, we are manually converting to actual null value
                    entry.admin_id = userID;
                }
                else if (userID.Substring(0, 1) == "E")
                {
                    entry.emp_id = userID;
                    entry.admin_id = "null";    
                }
                entry.clock_date = DateTime.Parse(clockDate_label.Content.ToString());
                entry.punchIn = TimeSpan.Parse(clockTime_label.Content.ToString());
                entry.mealOut = TimeSpan.Zero;  //to give 0 value so on restAPI side we can manually convert to actual null value
                entry.mealIn = TimeSpan.Zero;
                entry.punchOut = TimeSpan.Zero;
                entry.totalHours = 0;   //to give 0 value so on restAPI side we can manually convert to actual null value

                response = await httpclient.PostAsJsonAsync("CreateTimeSheetEntry", entry);
            }
            else if (mealOut_radio.IsChecked == true)
            {
                ArrayList times = new ArrayList();
                times.Add(clockTime_label.Content.ToString());

                response = await httpclient.PutAsJsonAsync("UpdateTimeSheetMealOut/" + timeID, times);
            }
            else if (mealIn_radio.IsChecked == true)
            {
                ArrayList times = new ArrayList();
                times.Add(clockTime_label.Content.ToString());

                response = await httpclient.PutAsJsonAsync("UpdateTimeSheetMealIn/" + timeID, times);
            }
            else if (punchOut_radio.IsChecked == true)
            {
                ArrayList times = new ArrayList();
                times.Add(clockTime_label.Content.ToString());

                response = await httpclient.PutAsJsonAsync("UpdateTimeSheetPunchOut/" + timeID, times);
            }
            else
            {
                MessageBox.Show("Please select one of the reasons");
                return;
            }

            var content = await response.Content.ReadAsStringAsync();

            if (content.Contains("Success, TimeSheet entry created"))
            {
                MessageBox.Show("Timesheet entry inserted succesfully");
            }
            else if (content.Contains("Success, TimeSheet entry updated"))
            {
                MessageBox.Show("Timesheet updated succesfully");
            }
            else if (content.Contains("Error, duplicate record detected. Can't punch in twice in a day."))
            {
                MessageBox.Show("Error, duplicate record detected");
            }
            else
            {
                MessageBox.Show("Error when handling request");
            }
        }

        private async void clockShow_button_Click(object sender, RoutedEventArgs e)
        {
            var serverResponse = await httpclient.GetStringAsync("GetAllTimeSheets/" + userID);

            Response responseJSON = JsonConvert.DeserializeObject<Response>(serverResponse);

            clockDbGrid.ItemsSource = responseJSON.listTimeSheets;

            clockDbGrid.Columns[0].Header = "Date (MM-dd-yyyy)";
            clockDbGrid.Columns[1].Header = "Punch In";
            clockDbGrid.Columns[2].Header = "Meal Out";
            clockDbGrid.Columns[3].Header = "Meal In";
            clockDbGrid.Columns[4].Header = "Punch Out";
            clockDbGrid.Columns[5].Header = "Hours";

            DataContext = this;
        }

        private void back_button_Click(object sender, RoutedEventArgs e)
        {
            Features window1 = new Features(userID);
            window1.Show();
            this.Close();
        }
    }
}
