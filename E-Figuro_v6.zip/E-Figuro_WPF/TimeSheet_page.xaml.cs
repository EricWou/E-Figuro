﻿using E_Figuro_API.Models;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace E_Figuro_WPF
{
    /// <summary>
    /// Interaction logic for TimeSheet_page.xaml
    /// </summary>
    public partial class TimeSheet_page : Window
    {
        HttpClient httpclient = new HttpClient();
        private string userID;

        public TimeSheet_page()
        {
            InitializeComponent();
        }

        public TimeSheet_page(string userID)
        {
            InitializeComponent();

            httpclient.BaseAddress = new Uri("https://localhost:7238/EFiguro/");

            httpclient.DefaultRequestHeaders.Accept.Clear();

            httpclient.DefaultRequestHeaders.Accept.Add
                (new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            this.userID = userID;

            InitializePage();
        }

        private async Task InitializePage()
        {
            await retrieveUserInfo();
        }

        private async Task retrieveUserInfo()
        {
            if (userID.Substring(0, 1) == "A")
            {
                var serverResponse = await httpclient.GetStringAsync("GetAdminUserByID/" + userID);
                Response response = JsonConvert.DeserializeObject<Response>(serverResponse);

                Administrator user = new Administrator();
                user = response.admin_user;

                if (response.status_code == 200)
                {
                    name_label.Content = user.admin_name;
                }
                else
                {
                    MessageBox.Show("Error with retrieving information");
                }
            }
            else if (userID.Substring(0, 1) == "E")
            {
                var serverResponse = await httpclient.GetStringAsync("GetEmpUserByID/" + userID);
                Response response = JsonConvert.DeserializeObject<Response>(serverResponse);

                Employee user = new Employee();
                user = response.emp_user;

                if (response.status_code == 200)
                {
                    name_label.Content = user.emp_name;
                }
                else
                {
                    MessageBox.Show("Error with retrieving information");
                }
            }
        }

        private async void fill_button_Click(object sender, RoutedEventArgs e)
        {
            DateTime? startDateValue = start_date.SelectedDate;         //the ? allows for nullable values
            DateTime? endDateValue = end_date.SelectedDate;

            if (startDateValue.HasValue && endDateValue.HasValue)
            {
                DateTime startDate = start_date.SelectedDate.Value.Date;
                DateTime endDate = end_date.SelectedDate.Value.Date;

                //to format the URL for the GET request
                string requestURL = $"?userID={userID}&startDate={startDate:MM-dd-yyyy}&endDate={endDate:MM-dd-yyyy}";

                var serverResponse = await httpclient.GetStringAsync("GetTimeSheetsByDate" + requestURL);

                Response responseJSON = JsonConvert.DeserializeObject<Response>(serverResponse);

                timesheet_grid.ItemsSource = responseJSON.listTimeSheets;

                //in order to change the column names
                timesheet_grid.Columns[0].Header = "Date (MM-dd-yyyy)";
                timesheet_grid.Columns[1].Header = "Punch In";
                timesheet_grid.Columns[2].Header = "Meal Out";
                timesheet_grid.Columns[3].Header = "Meal In";
                timesheet_grid.Columns[4].Header = "Punch Out";
                timesheet_grid.Columns[5].Header = "Hours";

                double totalHours = 0;

                if (responseJSON.listTimeSheets != null)
                {
                    //goes through each item inside the array listTimeSheets
                    foreach (var item in responseJSON.listTimeSheets)
                    {
                        totalHours += item.totalHours;
                    }
                }

                DataContext = this;

                totalHours_label.Content = totalHours.ToString();
            }
            else
            {
                MessageBox.Show("Please select a from and to date");
            }

            //the following options also work
            //string requestURL = $"?userID={userID}&startDate={startDate:yyyy-MM-dd}&endDate={endDate:yyyy-MM-dd}";
            //string requestURL = $"?userID={userID}&startDate={startDate:MM-dd-yyyy}&endDate={endDate:MM-dd-yyyy}"; 

            //string requestURL = $"GetTimeSheetsByDate?userID={userID}&startDate={startDate:yyyy-MM-dd}&endDate={endDate:yyyy-MM-dd}";   
            //var serverResponse = await httpclient.GetStringAsync(requestURL);   
        }

        private void print_button_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog dialog = new PrintDialog();
            if (dialog.ShowDialog() == true)
            {
                dialog.PrintVisual(this, "My Canvas");
            }
        }

        private void back_button_Click(object sender, RoutedEventArgs e)
        {
            Features window1 = new Features(userID);
            window1.Show();
            this.Close();
        }
    }
}
