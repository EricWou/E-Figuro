﻿using E_Figuro_WPF.Models;
using System.Collections;
using System.Collections.Generic;

namespace E_Figuro_API.Models
{
    public class Response
    {
        public int status_code { get; set; }
        public string status_message { get; set; }
        public Administrator admin_user { get; set; }
        public Employee emp_user { get; set; }
        public TimeSheet user_TimeSheet { get; set; }
        public Leave leave_request { get; set; }
        public int days_remaining { get; set; } //variable for passing through holiday/sick days remaining from Leave
        public double totalHours { get; set; }  //variable for passing through hour information for TimeSheet
        public ArrayList times { get; set; }    //ArrayList for passing through login information
        public List<TimeSheet_print> listTimeSheets { get; set; }   //List for datatable column information
        public ArrayList login { get; set; }    //ArrayList for passing through login information

    }
}
